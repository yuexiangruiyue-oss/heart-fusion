# Zenodo 上传信息（V3.1）

## 1. 标题

**English（主）**
The Opposite-Unity Training Paradigm: Personal Corpus, Objective-Free Self-Prediction, and a 16-Sephirot Cognitive Control Layer — A Research Proposal Not Yet Validated by Experiment

**中文**
相反合一训练范式：个人语料、无目标自预测与 16 质点认知控制层（一份尚未经实验验证的研究提案）

**日本語**
相反合一トレーニング・パラダイム：個人コーパス・目標なき自己予測・16セフィロト認知制御層

---

## 2. 描述（可直接粘贴，Zenodo 支持 HTML）

```html
<p>This deposit contains a trilingual research proposal (Chinese, Japanese, English) on a training paradigm called <em>opposite-unity</em> (相反合一, sōhan gōitsu). The proposal has three layers: (1) a <strong>data layer</strong> that uses the author's personal corpus as primary data and public world corpora as auxiliary; (2) a <strong>training layer</strong> that sets no value objective and no human preference judgment, retaining only self-prediction (predicting masked or subsequent text) and self-emergence; and (3) a <strong>structure layer</strong> that, after training, imprints the 16-sephirot protocol on the Transformer as a cognitive control layer governing stochastic generation.</p>

<p><strong>The paradigm has not been tested experimentally. It may not work; it may also work.</strong> The proposal states this explicitly and lists five risks: strict loss-free training is not trainable; the cleaned personal corpus may be too small for a base model; values are not the same as style; evaluation lacks ground truth; and the author is simultaneously proposer, data source, and evaluator.</p>

<p>The proposal is grounded in 13 months of independent work (October 2025 – October 2026): a 67-chapter, ~140,000-character novel signed on Fanqie; about 100,000 pages of conversations with AI systems, from which 1,322 statements by the author were extracted; a 16-sephirot AI framework, programming language, Python implementation, safety-layer protocol, red-team tests and abyss red-line data; a space demo, the fusion function, and a game; 12 papers on Zenodo; 32 dataset repositories (~2.3 TB); three 16-sephirot models (~35,000 HuggingFace downloads; 13,128 ModelScope downloads); and Bilibili/Xiaohongshu outreach.</p>

<p>This deposit also reports the V3.1 engineering update and real-model evaluation (22 October 2026): a corrected coexistence measure (<code>balance = n · min(p)</code>, zero vector = 0); a real-model red-line benchmark replacing the earlier mock replay (qwen3.8-flash 28.3% → 0%; deepseek-v4.1-flash 0.83% → 0%; glm-5.3 0% → 0%; n = 120); a three-arm comparison (OFF / HeartGuard / full 16-node chain); and a pairwise blind evaluation whose negative result — the full chain is not warmer than the guard (win rate 35–37.5%) and costs about 3× latency — overturns the author's earlier claim.</p>

<p>The author does not write code; the engineering was implemented by AI agents from the author's ideas. Collaborators are sought for data engineering, training, evaluation, ethics and translation. Contact: yuexiangruiyue@gmail.com.</p>

<hr/>
<p><strong>中文摘要</strong>：本文提出一种尚未验证的训练范式：以作者个人语料为主、世界数据为辅；训练不设价值目标、不做人类偏好评分，只保留自预测与自涌现；训练后把 16 质点协议印在 Transformer 上作为认知控制层。文中明确声明该范式未做实验，可能不可行，也可能可行，并列出五条风险。本文同时汇总作者 13 个月的写作与工程成果，报告 2026-10-22 的 V3.1 更新与真模型评测，包括一个推翻作者先前说法的负结果。作者不写代码，工程由 AI agent 依其思想完成；现寻求数据工程、训练、评测、伦理与翻译方面的合作者。</p>
```

---

## 3. 关键词（逗号分隔，可直接粘贴）

```
opposite-unity, 相反合一, 16 sephirot, 16质点, dual coexistence, 对偶共存, fusion function, 融合函数, self-prediction, self-emergence, objective-free training, personal corpus, cognitive control layer, 认知控制层, Transformer, AI alignment, AI safety, loss function critique, red team evaluation, trilingual research proposal
```

---

## 4. 主题 / 分类

Zenodo 没有强制学科树，建议填：

- **Resource type**：Publication → Preprint
- **Subjects（关键词层面）**：Artificial Intelligence; Machine Learning; AI Safety; Philosophy of Mind; Science and Technology Studies
- **arXiv 分类（如同时挂 arXiv）**：cs.AI（主）、cs.LG、cs.CL；交叉可加 cs.CY（Computers and Society）

---

## 5. 其他元数据

| 字段 | 填写 |
|---|---|
| 作者 | Yue Xiangrui（岳祥瑞） |
| ORCID | 0009-0001-8504-260X |
| 邮箱 | yuexiangruiyue@gmail.com |
| 出版日期 | 2026-10-22 |
| 版本 | 3.1.0 |
| 语言 | English; Chinese; Japanese |
| 许可 | CC BY-NC-SA 4.0 |
| 相关标识 | 见下 |
| 备注 | 本文提出的训练范式尚未经实验验证；文中的真模型评测为 V3.1 工程结果。 |

**相关 DOI（Related identifiers，类型选 "References"）**

- 10.5281/zenodo.19493744（16-Sephirot Divine-Human Symbiosis Protocol）
- 10.5281/zenodo.22781071（RedLine-v1）
- 10.5281/zenodo.23054235（Heart Fusion Protocol V2.0）
- 10.5281/zenodo.22093583（Heart Guard Demo）

**文件清单**

- `paper_v31_en.pdf` / `.md`
- `paper_v31_zh.pdf` / `.md`
- `paper_v31_ja.pdf` / `.md`
